import numpy as np
import cv2
import datetime

# set to 1 for pipeline images
debug = 0


def EntranceCrossing(y, ent, exi):
    if ent - y < 10 and y < ent:
        return 1
    else:
        return 0


def ExitCrossing(y, ent, exi):
    if y - exi < 8 and y > exi:  # there is a possibility that during entry also this'll be calculated
        return 1
    else:
        return 0


class Detectors(object):
    def __init__(self):
        self.fgbg = cv2.createBackgroundSubtractorMOG2()
        self.ExitCounter = 0
        self.EntranceCounter = 0

    def Detect(self, frame):
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        resize = cv2.GaussianBlur(gray, (21, 21), 0)
        if debug == 1:
            cv2.imshow('gray', gray)

        # Perform Background Subtraction
        fgmask = self.fgbg.apply(resize)

        if debug == 0:
            cv2.imshow('bgsub', fgmask)

        # Detect edges
        edges = cv2.Canny(fgmask, 100, 190, 3)

        if debug == 1:
            cv2.imshow('Edges', edges)

        # Retain only edges within the threshold
        ret, thresh = cv2.threshold(edges, 25, 200, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

        # Find contours
        _, contours, hierarchy = cv2.findContours(thresh,
                                                  cv2.RETR_EXTERNAL,
                                                  cv2.CHAIN_APPROX_SIMPLE)

        if debug == 0:
            cv2.imshow('thresh', thresh)

        centers = []  # vector of object centroids in a frame
        # we only care about centroids with size of bug in this example
        # recommended to be tunned based on expected object size for
        # improved performance
        centroids = []
        blob_radius_thresh = 10
        # Find centroid for each valid contours
        for cnt in contours:
            if cv2.contourArea(cnt) > 4000:

                try:
                    # Calculate and draw circle
                    (x, y, w, h) = cv2.boundingRect(cnt)

                    (x, y), radius = cv2.minEnclosingCircle(cnt)
                    cent = (int(x), int(y))
                    centroids.append(cent)
                    centeroid = (int(x), int(y))

                    YCentroid = (y + y + h) / 2
                    radius = int(radius)
                    if radius > blob_radius_thresh:
                        cv2.circle(frame, centeroid, radius, (0, 255, 0), 2)
                        if ExitCrossing(YCentroid, 350, 350):
                            self.ExitCounter += 1
                        if EntranceCrossing(YCentroid, 350, 350):
                            self.EntranceCounter += 1
                        b = np.array([[x], [y]])
                        centers.append(np.round(b))
                except ZeroDivisionError:
                    pass
        cv2.imshow('Track Bugs', frame)
        cv2.imshow('Edges', edges)
        # show contours of tracking objects
        # cv2.imshow('Track Bugs', frame)

        return centers
